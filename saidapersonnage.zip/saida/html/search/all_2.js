var searchData=
[
  ['deplacerperso_14',['deplacerperso',['../personnage_8h.html#a5167132e00f1edd8dd25c9d5ed1893c4',1,'deplacerperso(personnage *p, int clic):&#160;personne.c'],['../personne_8c.html#a5167132e00f1edd8dd25c9d5ed1893c4',1,'deplacerperso(personnage *p, int clic):&#160;personne.c']]]
];
