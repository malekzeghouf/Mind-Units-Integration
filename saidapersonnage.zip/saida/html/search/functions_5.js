var searchData=
[
  ['initperso_83',['initperso',['../personnage_8h.html#a77ee50e98679f2ea28b27e5ccdf50d28',1,'initperso(personnage *p):&#160;personne.c'],['../personne_8c.html#a77ee50e98679f2ea28b27e5ccdf50d28',1,'initperso(personnage *p):&#160;personne.c']]],
  ['initperso2_84',['initperso2',['../personnage_8h.html#af3c366a694e6bd24a5638600b55ee66c',1,'initperso2(personnage *p):&#160;personne.c'],['../personne_8c.html#af3c366a694e6bd24a5638600b55ee66c',1,'initperso2(personnage *p):&#160;personne.c']]]
];
