var searchData=
[
  ['score_61',['score',['../structscore.html',1,'']]]
];
