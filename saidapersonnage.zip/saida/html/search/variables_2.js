var searchData=
[
  ['number_92',['number',['../structscore.html#ad7ea11c12f350afe681f17e7497b3d13',1,'score']]],
  ['number1_93',['number1',['../structscore.html#ab6152d1b7fabf062bbbb15a6f5fd4387',1,'score']]]
];
