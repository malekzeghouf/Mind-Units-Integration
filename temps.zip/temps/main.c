#include<stdio.h>
#include<stdlib.h>
#include<string.h>

#include"SDL/SDL.h"
#include"SDL/SDL_image.h"
#include"SDL/SDL_mixer.h"
#include"time.h"

int  main()
{




afficher_chrono();













}
