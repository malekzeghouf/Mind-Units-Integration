#include "st1.h"

int stage1(SDL_Surface* screen, int t){

//declaration & init background
background bg;
initialiser_back(&bg);
int a=1; //a -> affichage entite (good)

//declaration & init entite
entite es;
initialiser_entite(&es,t);

//declaration et init fps
Uint32 t_dep,t_fin,dt=1;
int fps=30;

//boucle pseudo infinie
SDL_EnableKeyRepeat(200,0); //refresh imput : (duree de la pression du boutton,intervalle de repetition)
int continuer=1;
SDL_Event event;
while (continuer) {
t_dep=SDL_GetTicks();

  es.col=0;

  if(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_QUIT:
  continuer=0;
      break;

    }
  }



//affichage background
affiche_back(&bg,screen);

//mise a jour et affichage entite
mise_a_jour_entite(&es/*,&p*/);

/*
if(detect_collision(&p,&es))
a=gestion_collision(&p,&es);
*/

if(a) afficher_entite(&es,screen);

SDL_Flip(screen);

//appliquer fps
t_fin=SDL_GetTicks();
dt=t_fin-t_dep;
if (1000/fps>dt) SDL_Delay (1000/fps-dt);

}

}
