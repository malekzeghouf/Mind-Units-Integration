#include <SDL/SDL.h>
#include <SDL/SDL_image.h>


typedef struct background
{SDL_Surface *img_bg;
SDL_Rect position_bg;
SDL_Rect position_ecran;
SDL_Rect camera;}background;


void initialiser_background1(background *b1);
void initialiser_background2(background *b2);
void afficher_background1(background b1, SDL_Surface *ecran);
void afficher_background2(background b2, SDL_Surface *ecran);
void scrolling(int direction,background * bg);
