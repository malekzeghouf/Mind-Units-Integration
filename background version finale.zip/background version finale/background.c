#include <stdio.h>
#include <stdlib.h> 
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "background.h"


void initialiser_background(background * bg)
{
SDL_Surface *img_bg=NULL;
bg->position_bg.x=0;
bg->position_bg.y=0;

//Pour le scrolling 
bg->camera.x=0;
bg->camera.y=0;

bg->img_bg = IMG_Load("mario.png"); }



void afficher_background(background bg, SDL_Surface * ecran)
{SDL_BlitSurface(bg.img_bg,NULL,ecran,&(bg.position_bg));
SDL_Flip(ecran);}




void scrolling(int direction,background * bg)
{
	if(direction==1)//marche à gauche
	{ bg->position_bg.x--;
	bg->camera.x--;
        if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}
	
	
	else if(direction==2)//marche à droite
	{bg->camera.x++;
        bg->position_bg.x++;
	if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}
			
	
	else if(direction==3)//saut en haut
	{bg->position_bg.y--;
	bg->camera.y--;
        if(bg->camera.y<=0)
	bg->camera.y=0;
	if(bg->camera.y>=5000-600)
	bg->camera.y=5000-600;}
	
	else if(direction==4)//saut en bas
	{bg->position_bg.y++;
	bg->camera.y++;
        if(bg->camera.y<=0)
	bg->camera.y=0;
	if(bg->camera.y>=5000-600)
	bg->camera.y=5000-600;}



	/*else if(direction==5)//course à droite
	{ bg->camera.x+=40;
	bg->position_bg.x+=40;
	if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}
			
	else if(direction==6)//course à gauche
	{ bg->position_bg.x--;
	bg->camera.x--;
        if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}*/
	
	
}




