#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "partage_ecran.h"




void initialiser_background1(background *b1)
{SDL_Surface *img_bg=NULL;
b1->position_bg.x=0;
b1->position_bg.y=0;

b1->position_ecran.x=0;
b1->position_ecran.y=0;
b1->position_ecran.w=1000/2;
b1->position_ecran.h=733;
//Pour le scrolling 
b1->camera.x=0;
b1->camera.y=((b1->position_bg.h)-733)/2;
b1->camera.w=1000/2;
b1->camera.h=733;
b1->img_bg = IMG_Load("mario.png"); }



void initialiser_background2(background *b2)
{SDL_Surface *img_bg=NULL;
b2->position_bg.x=0;
b2->position_bg.y=0;

b2->position_ecran.x=1000/2;
b2->position_ecran.y=0;
b2->position_ecran.w=1000/2;
b2->position_ecran.h=733;
//Pour le scrolling 
b2->camera.x=0;
b2->camera.y=((b2->position_bg.h)-733)/2;
b2->camera.w=1000(b2->position_ecran.w)/2;
b2->camera.h=733;
b2->img_bg=IMG_Load("mario.png"); }


void afficher_background1(background b1, SDL_Surface *ecran)
{SDL_BlitSurface(b1.img_bg,NULL,ecran,&(b1.position_bg));
SDL_Flip(ecran);}


void afficher_background2(background b2, SDL_Surface *ecran)
{SDL_BlitSurface(b2.img_bg,NULL,ecran,&(b2.position_bg));
SDL_Flip(ecran);}


void scrolling(int direction,background * bg)
{
	if(direction==1)//marche à gauche
	{ bg->position_bg.x--;
	bg->camera.x--;
        if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}
	
	
	else if(direction==2)//marche à droite
	{bg->camera.x++;
        bg->position_bg.x++;
	if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}
			
	
	else if(direction==3)//saut en haut
	{bg->position_bg.y--;
	bg->camera.y--;
        if(bg->camera.y<=0)
	bg->camera.y=0;
	if(bg->camera.y>=5000-600)
	bg->camera.y=5000-600;}
	
	else if(direction==4)//saut en bas
	{bg->position_bg.y++;
	bg->camera.y++;
        if(bg->camera.y<=0)
	bg->camera.y=0;
	if(bg->camera.y>=5000-600)
	bg->camera.y=5000-600;}



	/*else if(direction==5)//course à droite
	{ bg->camera.x+=40;
	bg->position_bg.x+=40;
	if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}
			
	else if(direction==6)//course à gauche
	{ bg->position_bg.x--;
	bg->camera.x--;
        if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}*/
	
	
}










