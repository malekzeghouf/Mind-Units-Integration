#include <stdio.h>
#include <stdlib.h> 
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include "background.h"

int main ()
{SDL_Surface *screen=NULL ;
background b;
int direction=0;
int continuer=1;
SDL_Event event;

SDL_Init(SDL_INIT_VIDEO);
screen = SDL_SetVideoMode(1000,733, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
initialiser_background(&b);
b.img_bg = IMG_Load("mario.png");


while(continuer)
{afficher_background(b,screen);
while (SDL_PollEvent(&event))
{if (event.type==SDL_QUIT)
continuer = 0;
else if (event.type==SDL_KEYDOWN)
{switch(event.key.keysym.sym)
{case SDLK_RIGHT :
direction=1;
scrolling(direction,&b);
afficher_background(b,screen);
break;
case SDLK_LEFT:
direction=2;
scrolling(direction,&b);
afficher_background(b,screen);
break;
case SDLK_DOWN:
direction=3;
scrolling(direction,&b);
afficher_background(b,screen);	
break ;
case SDLK_UP:
direction=4;
scrolling(direction,&b);
afficher_background(b,screen);	
break ;}}}
afficher_background(b,screen);
SDL_Flip(screen);}
SDL_FreeSurface(screen);
SDL_Quit();
return 0;}
