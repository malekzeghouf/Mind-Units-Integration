#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "partage_ecran.h"
#define largeur 1000
#define hauteur 733

void initialiser_background1(background *b)
{b->pb.x=0;
b->pb.y=0;
b->pb.w=largeur;
b->pb.h=hauteur/2;
//Pour le scrolling 
b->camera.x=0;
b->camera.y=0;
b->camera.w=largeur;
b->camera.h=hauteur/2;
b->img_bg=IMG_Load("mario.png");}



void initialiser_background2(background *b)
{b->pb.x=0;
b->pb.y=hauteur/2;
b->pb.w=largeur;
b->pb.h=hauteur/2;
//Pour le scrolling 
b->camera.x=0;
b->camera.y=hauteur/2;
b->camera.w=largeur;
b->camera.h=hauteur/2;
b->img_bg=IMG_Load("mario.png");}



/*void initialiser_background1(background *b1)
{SDL_Surface *img_bg=NULL;
//b1->position_bg=NULL;
b1->position_ecran.x=0;
b1->position_ecran.y=0;
b1->position_ecran.w=1000/2;
b1->position_ecran.h=733;
//Pour le scrolling 
b1->camera.x=0;
b1->camera.y=733;
b1->camera.w=1000/2;
b1->camera.h=733;
b1->img_bg = IMG_Load("mario.png");}


void initialiser_background2(background *b2)
{SDL_Surface *img_bg=NULL;
//b2->position_bg=NULL;

b2->position_ecran.x=1000/2;
b2->position_ecran.y=0;
b2->position_ecran.w=1000/2;
b2->position_ecran.h=733;
//Pour le scrolling 
b2->camera.x=0;
b2->camera.y=733;
b2->camera.w=1000/2;
b2->camera.h=733;
b2->img_bg=IMG_Load("mario.png"); }*/


void afficher_background(background b, SDL_Surface *ecran)
{SDL_BlitSurface(b.img_bg,NULL,ecran,&(b.pb));}



void scrolling(int direction,background * bg)
{
	if(direction==1)//marche à gauche
	{ bg->pb.x--;
	bg->camera.x--;
        if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}
	
	
	else if(direction==2)//marche à droite
	{bg->camera.x++;
        bg->pb.x++;
	if(bg->camera.x<=0)
	bg->camera.x=0;
	if(bg->camera.x>=5000-600)
	bg->camera.x=5000-600;}
			
	
	else if(direction==3)//saut en haut
	{bg->pb.y--;
	bg->camera.y--;
        if(bg->camera.y<=0)
	bg->camera.y=0;
	if(bg->camera.y>=5000-600)
	bg->camera.y=5000-600;}
	
	else if(direction==4)//saut en bas
	{bg->pb.y++;
	bg->camera.y++;
        if(bg->camera.y<=0)
	bg->camera.y=0;
	if(bg->camera.y>=5000-600)
	bg->camera.y=5000-600;}}   
















