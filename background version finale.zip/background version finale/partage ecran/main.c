#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "partage_ecran.h"


int main(int argc, char *argv[])
{SDL_Surface *screen=NULL ;
background b1;
background b2;
int direction=0;
int continuer=1;
SDL_Event event;

SDL_Init(SDL_INIT_VIDEO);
screen = SDL_SetVideoMode(1000,733, 32, SDL_HWSURFACE|SDL_DOUBLEBUF);
initialiser_background1(&b1);
initialiser_background2(&b2);



while(continuer)
{afficher_background(b1,screen);
afficher_background(b2,screen);
while (SDL_PollEvent(&event))
{if (event.type==SDL_QUIT)
continuer = 0;
else if (event.type==SDL_KEYDOWN)
{switch(event.key.keysym.sym)
{case SDLK_RIGHT :
direction=1;
scrolling(direction,&b1);
afficher_background(b1,screen);
break;
case SDLK_LEFT:
direction=2;
scrolling(direction,&b1);
afficher_background(b1,screen);
break;
case SDLK_DOWN:
direction=3;
scrolling(direction,&b1);
afficher_background(b1,screen);	
break ;
case SDLK_UP:
direction=4;
scrolling(direction,&b1);
afficher_background(b1,screen);	
break ;
case SDLK_d :
direction=1;
scrolling(direction,&b2);
afficher_background(b2,screen);
break;
case SDLK_g:
direction=2;
scrolling(direction,&b2);
afficher_background(b2,screen);
break;
case SDLK_v:
direction=3;
scrolling(direction,&b2);
afficher_background(b2,screen);	
break ;
case SDLK_SPACE:
direction=4;
scrolling(direction,&b2);
afficher_background(b2,screen);	
break ;}}}
afficher_background(b1,screen);
afficher_background(b2,screen);
SDL_Flip(screen);}
SDL_FreeSurface(screen);
SDL_Quit();
return 0;   

 

}
