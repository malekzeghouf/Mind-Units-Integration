#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#define largeur 1000
#define hauteur 733

typedef struct background
{SDL_Surface *img_bg;
SDL_Rect pb;
SDL_Rect camera;}background;


void initialiser_background1(background *b);
void initialiser_background2(background *b);
void afficher_background(background b, SDL_Surface *ecran);
void scrolling(int direction,background * bg);

